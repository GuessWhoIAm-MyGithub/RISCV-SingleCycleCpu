#this is an decoder for hex instructions
rtype='0110011'
r_immtype='0010011'
loadtype='0000011'
storetype='0100011'
beqtype='1100011'
lui='0110111'
auipc='0010111'
jal='1101111'
jalr='1100111'

inst=[]
def getOpcode(instruction):
    opcode=instruction[25:]
    return opcode

def sep_lui(instruction):
    name='lui'
    rd=int(instruction[20:25],base=2)
    imm=int(instruction[0:20],base=2)
    return name,rd,imm

def sep_auipc(instruction):
    name='auipc'
    rd=int(instruction[20:25],base=2)
    imm = int(instruction[0:20],base=2)
    return name,rd,imm

def sep_jal(instruction):
    name='jal'
    rd=int(instruction[20:24],base=2)
    imm=int(instruction[0]+instruction[12:20]+instruction[11]+instruction[1:11],base=2)<<1
    return name,rd,imm

def sep_jalr(instruction):
    name='jalr'
    rd=int(instruction[20:25],base=2)
    rs1=int(instruction[12:17],base=2)
    imm=int(instruction[0:12],base=2)
    return name,rd,rs1,imm

def sep_beqtype(instruction):
    func3=instruction[17:20]
    func3_dict={'000':'beq','001':'bne','100':'blt','101':'bge','110':'bltu','111':'bgeu'}
    name=func3_dict[func3]
    rs1=int(instruction[12:17],base=2)
    rs2=int(instruction[7:12],base=2)
    imm=int(instruction[0]+instruction[24]+instruction[1:7]+instruction[20:24],base=2)<<1
    return name,rs1,rs2,imm

def sep_loadtype(instruction):
    func3=instruction[17:20]
    func3_dict={'000':'lb','001':'lh','010':'lw','100':'lbu','101':'lhu'}
    name=func3_dict[func3]
    rd=int(instruction[20:25],base=2)
    rs1=int(instruction[12:17],base=2)
    imm=int(instruction[0:12],base=2)
    return name,rd,rs1,imm

def sep_storetype(instruction):
    func3=instruction[17:20]
    func3_dict={'000':'sb','001':'sh','010':'sw'}
    name=func3_dict[func3]
    rs1=int(instruction[12:17],base=2)
    rs2=int(instruction[7:12],base=2)
    imm=int(instruction[0:7]+instruction[20:25],base=2)
    return name,rs1,rs2,imm

def sep_r_immtype(instruction):
    if instruction[17:20]=='101':
        if instruction[0:7]=='0000000':
            name='srli'
            rd=int(instruction[20:25],base=2)
            rs1=int(instruction[12:17],base=2)
            imm=int(instruction[7:12],base=2)
            return name, rd, rs1, imm
        if instruction[0:7]=='0100000':
            name='srai'
            rd = int(instruction[20:25], base=2)
            rs1 = int(instruction[12:17], base=2)
            imm = int(instruction[7:12], base=2)
            return name,rd,rs1,imm
    elif instruction[17:20]=='001':
            name='slli'
            rd = int(instruction[20:25], base=2)
            rs1 = int(instruction[12:17], base=2)
            imm = int(instruction[7:12], base=2)
            return name, rd, rs1, imm
    else:
        func3_dict={'000':'addi','010':'slti','011':'sltiu','100':'xori','110':'ori','111':'andi'}
        func3=instruction[17:20]
        #print(type(func3))
        name=func3_dict[func3]
        rd=int(instruction[20:25],base=2)
        rs1=int(instruction[12:17],base=2)
        imm=int(instruction[0:12],base=2)
        return name,rd,rs1,imm

def sep_rtype(instruction):

    func3=instruction[17:20]
    func7=instruction[0:7]
    func3_dict={'001':'sll','010':'slt','011':'sltu','100':'xor','110':'or','111':'and'}
    if func3=='000':
        if func7=='0000000':
            name='add'
        elif func7=='0100000':
            name='sub'
    elif func3=='101':
        if func7=='0000000':
            name='srl'
        elif func7=='0100000':
            name='sra'
    else:
        name=func3_dict[func3]
    rd=int(instruction[20:25],base=2)
    rs1=int(instruction[12:17],base=2)
    rs2=int(instruction[7:12],base=2)
    return name,rd,rs1,rs2
def getSequence(instruction):
    opcode=getOpcode(instruction)
    if opcode==lui:
        name,rd,imm=sep_lui(instruction)
        info=name+' '+'x'+str(rd)+' '+str(hex(imm))
        inst.append(info)
        print(name+' '+'x'+str(rd)+' '+str(hex(imm)))
    if opcode==auipc:
        name,rd,imm=sep_auipc(instruction)
        info=name+' '+'x'+str(rd)+' '+str(hex(imm))
        inst.append(info)
        print(name+' '+'x'+str(rd)+' '+str(hex(imm)))
    if opcode==jal:
        name,rd,imm=sep_jal(instruction)
        info=name+' ' + 'x' + str(rd) + ' ' + str(hex(imm))
        inst.append(info)
        print(name+' '+'x'+str(rd)+' '+str(hex(imm)))
    if opcode==jalr:
        name,rd,rs1,imm=sep_jalr(instruction)
        info=name+' '+'x'+str(rd)+' '+str(hex(imm))+'('+'x'+str(rs1)+')'
        inst.append(info)
        print(name+' '+'x'+str(rd)+' '+str(hex(imm))+'('+'x'+str(rs1)+')')
    if opcode==beqtype:
        name,rs1,rs2,imm=sep_beqtype(instruction)
        info=name+' '+'x'+str(rs1)+' '+'x'+str(rs2)+' '+str(hex(imm))
        inst.append(info)
        print(name+' '+'x'+str(rs1)+' '+'x'+str(rs2)+' '+str(hex(imm)))
    if opcode==loadtype:
        name,rd,rs1,imm=sep_loadtype(instruction)
        info=name+' '+'x'+str(rd)+' '+str(hex(imm))+'('+'x'+str(rs1)+')'
        inst.append(info)
        print(name+' '+'x'+str(rd)+' '+str(hex(imm))+'('+'x'+str(rs1)+')')
    if opcode ==storetype:
        name,rs1,rs2,imm=sep_storetype(instruction)
        info=name+' '+'x'+str(rs2)+' '+str(hex(imm))+'('+'x'+str(rs1)+')'
        inst.append(info)
        print(name+' '+'x'+str(rs2)+' '+str(hex(imm))+'('+'x'+str(rs1)+')')
    if opcode==r_immtype:
        name,rd,rs1,imm=sep_r_immtype(instruction)
        info=name+' '+'x'+str(rd)+' '+'x'+str(rs1)+' '+str(hex(imm))
        inst.append(info)
        print(name+' '+'x'+str(rd)+' '+'x'+str(rs1)+' '+str(hex(imm)))
    if opcode==rtype:
        name,rd,rs1,rs2=sep_rtype(instruction)
        info=name + ' ' + 'x' + str(rd) + ' ' + 'x' + str(rs1) + ' ' + 'x' + str(rs2)
        inst.append(info)
        print(name+' '+'x'+str(rd)+' '+'x'+str(rs1)+' '+'x'+str(rs2))

