from GetSequence import *
file=open(r'E:\ClassFile\PPT+PDF\ComputerDesign\RISCV-SingleCycleCpu-main\RISCV-SingleCycleCpu-main\testInstruction\testIns4.txt')
while True:
    line=file.readline()
    #print(line)
    #line=input()
    if line:
        instruction='{:032b}'.format(int(line,base=16))
   # print(instruction,len(instruction))
        getSequence(instruction)
