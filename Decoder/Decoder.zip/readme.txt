Just change your filepath in the file decoder.py

Note: the instruction format should be hexadecimal and without prefix——0x